<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

define("ESTEL_IP","127.0.0.1;195.24.207.114");
define("PATH_ERROR_DB", "./logs/bd/");
define("PATH_ERROR_SIMPLE", "./logs/");
define("DB_HOST", "localhost");
define("DB_NAME", "db_eumobile_api");
define("DB_USER", "root");
define("DB_PASS", "");
define("MAX_AMOUNT", 100000);
define("MIN_AMOUNT", 100);
define("NB_ACCEPTED_KEYS", 3);
define("PAYMENT_TIMEOUT", 12);
define("PAYMENT_SLEEP_TIMEOUT", 10);
define("VALID_PHONE_LIST", "237=>12;"); //,235=>10;033=>12
define("ENCRYPT_KEY", "eumobile_api"); //,235=>10;033=>12
define("URL_WECASHUP","api/v1.0/providers/eu/webhook");
