<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$langFront = array();

$langFront["Label"][0] = "EU Mobile API";
$langFront["Label"][1] = "please make sure all required fields are set";
$langFront["Label"][2] = "This client is not yet allowed to use this service";
$langFront["Label"][3] = "You are not authorized to access this service, or internal server error";
$langFront["Label"][4] = "Required inputs not set";
$langFront["Label"][5] = "Partner Key reset successfully";
$langFront["Label"][6] = "Unknown service";
$langFront["Label"][7] = "Transaction Successful";
$langFront["Label"][8] = "Transaction Failed";
$langFront["Label"][9] = "Service API not set";
$langFront["Label"][10] = "Unknown result";
$langFront["Label"][11] = "Payment request pending";
$langFront["Label"][12] = "Payment request approved succesfully";
$langFront["Label"][13] = "Invalid Request";
$langFront["Label"][14] = "Data succesfully received";
$langFront["Label"][15] = "Internal server error";
$langFront["Label"][16] = "Invalid input parameters";
$langFront["Label"][17] = "Unable to access to core platform";
$langFront["Label"][18] = "General error";
$langFront["Label"][19] = "Biller not found";
//$langFront["Label"][20] = "Payment not found";
