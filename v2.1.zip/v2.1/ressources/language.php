<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$langFront = array();

$langFront["Label"][0] = "EU Mobile API";
$langFront["Label"][1] = "please make sure all required fields are set";
$langFront["Label"][2] = "This client is not yet allowed to use this service";
$langFront["Label"][3] = "You are not authorized to access this service";
$langFront["Label"][4] = "All required arguments are not defined";
$langFront["Label"][5] = "Partner Key reset successfully";
$langFront["Label"][6] = "Unknown service";
$langFront["Label"][7] = "Transaction Successful";
$langFront["Label"][8] = "Transaction Failed";
$langFront["Label"][9] = "Service API not set";
$langFront["Label"][10] = "Unknown result";
$langFront["Label"][11] = "Payment request cancelled";
$langFront["Label"][12] = "Payment request approved succesfully";
$langFront["Label"][13] = "Invalid Request";
$langFront["Label"][14] = "Data succesfully received";
$langFront["Label"][15] = "This billno is already used";
$langFront["Label"][16] = "Invalid input parameters";
$langFront["Label"][17] = "Unable to access to core platform";
$langFront["Label"][18] = "General error";
$langFront["Label"][19] = "Biller/Merchant not found";
$langFront["Label"][20] = "Invalid number format";
$langFront["Label"][21] = "Subscriber not found";
$langFront["Label"][22] = "Bill not found";
$langFront["Label"][23] = "This subscriber is not eligible to this service";
$langFront["Label"][24] = "Subscriber is not active";
$langFront["Label"][25] = "Transaction not found";
$langFront["Label"][26] = "Bill already paid";
$langFront["Label"][27] = "Commission account not found in core platform";
$langFront["Label"][28] = "Holding account not found";
$langFront["Label"][29] = "Billpay amount is out of range";
$langFront["Label"][30] = "Bill due date expired";
$langFront["Label"][31] = "Amount is invalid or out of range";
$langFront["Label"][32] = "Phone format is invalid";
$langFront["Label"][33] = "Request cancelled due to duplicate reference id";
$langFront["Label"][34] = "Failed to connect to core platform";
