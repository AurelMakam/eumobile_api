#!/usr/bin/perl
#
# @File Send_Data_To_UDS.pl
# @Author EU
# @Created 21 août 2015 09:13:31
#

use strict;
use DBI;
use warnings;
use DateTime;
use Net::FTP;
use LWP::UserAgent;
use File::Spec;
use JSON;
#connexion à la base de données

my $ua = LWP::UserAgent->new;
my ($volume, $directory, $file) = File::Spec->splitpath(__FILE__);
my $last_char = substr $directory, -1;
if($last_char ne "/") {
    $directory = $directory."/";
}
if (length ($directory) == 1) {
    $directory = "";
}
# décommenter la ligne ci-dessous sous Windows
print "directory = ".$directory;
$directory = "";
my $db      =   "db_eumobile_api";
my $host    =   "213.251.146.170";
my $port    =   "3306";
my $user    =   "eumm_api";
my $pwd     =   "DbEUmmAPi@!";
#Parametres de chque partenaire
my $id_go_groups = "8";
my $id_buea = "11";
my $post_url_go_groups   =   "https://p-r.site/payments_api/eu_money_payment_notification_api_v1.php";
my $post_url_ubuea   =   "https://dev.go-student.net/test/public/index.php/student/payment/eu/tuition_medical/fee/notify";
my $post_url = "";
mkdir($directory."last_transaction");
open my $writing, ">>:encoding(utf8)", $directory."last_transaction/last_transaction.txt" or die "impossible d'ouvrir le fichier:  last_transaction: $!";
close $writing;
open my $reading, "<:encoding(utf8)", $directory."last_transaction/last_transaction.txt" or die "impossible d'ouvrir le fichier:  last_transaction: $!";
my $lastid = "0";
if(my $lid = <$reading>) {
    chomp($lid);
    if($lid ne "") {
        $lastid = $lid;
    }
}
close $reading;
print "lastid = ".$lastid."\n";
my $bdd = DBI->connect("dbi:mysql:dbname=$db;host=$host;port=$port",$user,$pwd) or die 'Connexion impossible : '.DBI::errstr;
my $req = "SELECT tb_paidtxn.*, tb_partner.col_id FROM tb_paidtxn  INNER JOIN tb_partner ON tb_partner.col_code=tb_paidtxn.col_dest_number WHERE col_trxn >= '".$lastid."' AND col_etat = 'not sent' ORDER BY tb_paidtxn.col_id DESC";
my $prep = $bdd->prepare($req);
$prep->execute();
print "nbre de lignes = ".$prep->rows()."\n";
if($prep->rows()>0) {
    #Recuperation de la date
    my $dt = DateTime->now();
    $dt =~ s/[^[:alnum:]]//g;
    #creation du fichier resultat

    while (my @val = $prep->fetchrow_array) {
        # ENVOI DES DONNEES PAR HTTP
        
        my $id= $val[0];
        my $src_number = $val[1];
        my $dest_number = $val[3];
        my $amount = $val[5];
        my @f = split (/\./ , $amount);
        $amount = $f[0];
        my $datetime = $val[7];
        my $reference = $val[8];
        my $trxn = $val[9];
        my $partner_id = $val[11];
        if ($partner_id eq $id_go_groups) {
            $post_url = $post_url_go_groups;
        }
        elsif ($partner_id eq $id_buea) {
            $post_url = $post_url_ubuea;
        }
        else {
        }
        if ($post_url eq $post_url_go_groups || $post_url eq $post_url_ubuea) {
            my $response = $ua->post(
        $post_url,
        [
            'phone'    => $src_number,
            'reference'    => $reference,
            'message'    => 'paid',
            'amount'    => $amount,
            'transaction_id'    => $trxn,
            'payment_date'    => $datetime,
            'submit' => 'SUBMIT'
        ],
            );
            print ( $response->content );
            my $resp = $response->content;
            my $message = decode_json($resp);
            my $status = $message-> {
                'statusCode'
            };
            if ($status eq "101") {
                # success
                open my $writing2, ">:encoding(utf8)", $directory."last_transaction/last_transaction.txt" or die "impossible d'ouvrir le fichier:  last_transaction: $!";
                print $writing2 $trxn;
                ($bdd->prepare("UPDATE tb_paidtxn set col_etat = 'sent' where col_id = '" . $id . "'"))->execute();
                #                mysql_query("UPDATE tb_paidtxn set col_etat = 'sent' where col_id = '" . $id . "'");
                print "the trxn ".$trxn." successfully sent to partner <br/>";
            }
            elsif ($status eq "105") {
                ($bdd->prepare("UPDATE tb_paidtxn set col_etat = 'sent' where col_id = '" . $id . "'"))->execute();
                print "the trxn ".$trxn." already sent to partner <br/>";
            }
        }
    }
    $prep->finish;
    print "done !!!";
}
else {
    print "no data to send yet !!!";
}
