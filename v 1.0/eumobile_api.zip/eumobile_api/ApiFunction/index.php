<?php
    $pos = strpos("bonjour", "ji");
    echo "pos = ".$pos;